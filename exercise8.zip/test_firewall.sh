#!/bin/bash

# Cleanup old namespace if it exists
ip netns delete fwtest >/dev/null 2>&1 || true

set -e

NS="fwtest"
NFT_FILE="nftables_firewall.nft"
PCAP="test_firewall.pcap"

# 1. Create network namespace
ip netns add $NS

# 2. Create a veth pair to connect namespace to root
ip link add veth0 type veth peer name veth1
ip link set veth1 netns $NS

# 3. Assign IP addresses
ip addr add 10.0.0.1/24 dev veth0
ip link set veth0 up
ip netns exec $NS ip addr add 10.0.0.2/24 dev veth1
ip netns exec $NS ip link set veth1 up
ip netns exec $NS ip link set lo up

# 4. Install nftables in the namespace
ip netns exec $NS nft -f $NFT_FILE

# 5. Replay PCAP in the namespace
tcpreplay -i veth0 $PCAP


# 6. Show counters for each rule
echo "=== Rule counters after replay ==="
ip netns exec $NS nft list ruleset | grep counter

# 7. Cleanup (optional)
#ip link delete veth0
