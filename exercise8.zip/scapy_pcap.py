#!/usr/bin/env python3
from scapy.all import *

pkts = []

# F1: 80 (accepted)
pkts.append(Ether()/IP(dst="10.0.0.2")/TCP(dport=80))
pkts.append(Ether()/IP(dst="10.0.0.2")/UDP(dport=443))

# F2: 35000 (dropped)
pkts.append(Ether()/IP(dst="10.0.0.2")/TCP(dport=35000))
pkts.append(Ether()/IP(dst="10.0.0.2")/UDP(dport=35000))

# F3: 36000 (accepted)
pkts.append(Ether()/IP(dst="10.0.0.2")/TCP(dport=36000))
pkts.append(Ether()/IP(dst="10.0.0.2")/UDP(dport=36000))

# F4: 300 (dropped)
pkts.append(Ether()/IP(dst="10.0.0.2")/TCP(dport=300))
pkts.append(Ether()/IP(dst="10.0.0.2")/UDP(dport=300))

# F6: 55000 (dropped)
pkts.append(Ether()/IP(dst="10.0.0.2")/TCP(dport=55000))
pkts.append(Ether()/IP(dst="10.0.0.2")/UDP(dport=55000))

wrpcap("test_firewall.pcap", pkts)
print("Generated test_firewall.pcap with Ethernet frames")
